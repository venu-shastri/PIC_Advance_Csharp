﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo
{
   public interface IA
    {
        void Method();
    }
    public class A:MarshalByRefObject, IA
    {
        public A() {

            Console.WriteLine($"Type A Instantiated in {AppDomain.CurrentDomain.FriendlyName}");
        }
        public void Method()
        {
            Console.WriteLine($"Method  Executing  in {AppDomain.CurrentDomain.FriendlyName}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //IA obj = new A();
           IA obj= AppDomain.CreateDomain("RemoteDomain1").
                    CreateInstanceAndUnwrap("demo","demo.A") as IA;
          
            Client(obj);
            
        }
        static void Client(IA objRef)
        {

            Console.WriteLine($"Client Code Executing  in {AppDomain.CurrentDomain.FriendlyName}");
            if (objRef != null)
            {
                objRef.Method(); // Local Calls
            }
        }
    }
}

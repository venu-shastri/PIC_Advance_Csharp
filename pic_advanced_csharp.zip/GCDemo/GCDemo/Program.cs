﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace GCDemo
{

    //[System.Runtime.Remoting.Contexts.Synchronization]
    public class Dispatcher //:System.ContextBoundObject
    {
        public static readonly Dispatcher Instance = new Dispatcher();
        private Object _syncDispatch = new object();
        private Object _syncSubScribeAndUnSubscribe = new object();
        private Dispatcher()
        {

        }
        List<Action> _subscribersList = new List<Action>();
        //[System.Runtime.CompilerServices.MethodImpl(
          //  System.Runtime.CompilerServices.MethodImplOptions.Synchronized)]
        public void Dispatch()
        {

            lock (_syncDispatch)
            {
                for (int i = 0; i < 10; i++)
                {
                    //  subscriber();
                    Console.WriteLine($"Dipatch in Action - {Thread.CurrentThread.Name}");
                    if (i == 5) { return; }
                    Thread.Sleep(1000);
                }
            }
            
        }

        //[System.Runtime.CompilerServices.MethodImpl(
          //  System.Runtime.CompilerServices.MethodImplOptions.Synchronized)]
        public void Subscribe(object subscriber)
        {
            Monitor.Enter(_syncSubScribeAndUnSubscribe);
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Subscribe in Action - {Thread.CurrentThread.Name}");
                Thread.Sleep(2000);
                //   _subscribersList.Add(subscriber as Action);
            }
            Monitor.Exit(_syncSubScribeAndUnSubscribe);
        }

      //  [System.Runtime.CompilerServices.MethodImpl(
        //    System.Runtime.CompilerServices.MethodImplOptions.Synchronized)]
        public void UnSbscribe(object subscriber)
        {
            Monitor.Enter(_syncSubScribeAndUnSubscribe);
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"UnSubscribe in Action - {Thread.CurrentThread.Name}");
                Thread.Sleep(3000);
                
            }
            Monitor.Exit(_syncSubScribeAndUnSubscribe);
            //_subscribersList.Remove(subscriber as Action);

        }

    }

    
    class Program
    {
    
        static void Main(string[] args)
        {
            System.Threading.Thread.CurrentThread.Name = "Main Thread";
            Thread _dispatcher = 
                new Thread(Dispatcher.Instance.Dispatch) { Name = "DispatcherThread" };
            _dispatcher.Start();

            Thread _subscriber = new Thread(Dispatcher.Instance.Subscribe) { Name = "Subscriber Thread" };
            _subscriber.Start();

            Thread _unsubscriber = new Thread(Dispatcher.Instance.UnSbscribe) { Name = "UnSubScriber Thread" };
            _unsubscriber.Start();

            Thread _Newdispatcher =
               new Thread(Dispatcher.Instance.Dispatch) { Name = "NewDispatcherThread" };
            _Newdispatcher.Start();

        }
        
    }
}

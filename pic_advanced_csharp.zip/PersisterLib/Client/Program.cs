﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    [PersisterLib.Persistable(
        PersistantFormat =PersisterLib.PersistanceFormat.JSON,
        PersistantMode =PersisterLib.PersistanceMode.PUBLIC)]
    public class Patient
    {
        [PersisterLib.PersistedName("PatientId")]
        public string MRN { get; set; }
        public string PatientName { get; set; }

        [PersisterLib.IgnoreAttribute]
        public string Email { get; set; }
    }
    class Program
    {
        
        static void Main(string[] args)
        {
            Patient _target = new Patient() { MRN = "P100", PatientName = "Tom", Email = "tom@pic.com" };
            PersisterLib.POCOPersister _persister = new PersisterLib.POCOPersister();
            _persister.Persist(_target);
            
        }
    }
}

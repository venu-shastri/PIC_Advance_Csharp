﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace NewSerializationDemo
{
    class ReferenceTypeSurrogate : System.Runtime.Serialization.ISerializationSurrogate
    {
        //Serialization
        public void GetObjectData(object obj, SerializationInfo info, StreamingContext context)
        {
            ReferenceType _objRef = obj as ReferenceType;
            info.AddValue(nameof(_objRef.member2), _objRef.member2);
            info.AddValue("member1",
                _objRef.GetType().
                GetField("member1",
                System.Reflection.BindingFlags.Instance |
                System.Reflection.BindingFlags.NonPublic).
                GetValue(obj).ToString());
        }

        //Deserialization
        public object SetObjectData(object obj, SerializationInfo info, StreamingContext context, ISurrogateSelector selector)
        {
           ReferenceType _objRef= obj as ReferenceType;
            _objRef.member2 = info.GetString("member2");
            return _objRef;

        }
    }
    

    
    class ReferenceTypeBinder:System.Runtime.Serialization.SerializationBinder
    {
        public override Type BindToType(string assemblyName, string typeName)
        {
            return typeof(ReferenceType);
        }
    }
    
    public class ReferenceType 
    {
        private int member3;
        private int member1 = 100;
        public string member2 = "Member2";

        public override string ToString()
        {
            return $"{member1} and {member2}";
        }

        public ReferenceType() { }
        //Deserialize
        
    }
    public class DeepSerializer
    {
        public void Serialize(object target,
            System.IO.Stream location,
            System.Runtime.Serialization.IFormatter formatter)
        {

            formatter.Serialize(location, target);
        }

        public object DeSerialize(System.IO.Stream location,
            System.Runtime.Serialization.IFormatter formatter)
        {
            object target = default(object);
            target = formatter.Deserialize(location);
            return target;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            SurrogateSelector _surrogateSelector = new SurrogateSelector();
            _surrogateSelector.
                AddSurrogate(
                typeof(ReferenceType), 
                new StreamingContext(StreamingContextStates.All), 
                new ReferenceTypeSurrogate());

            DeepSerializer _serializer = new DeepSerializer();
            System.IO.StreamWriter _writer = new System.IO.StreamWriter("..//..//ReferenceType.bin");
            _serializer.Serialize(new ReferenceType(), _writer.BaseStream,
                new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter()
                {
                    SurrogateSelector = _surrogateSelector          
                  });

        
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.IO;
using System.Runtime.Serialization;

namespace SerializationDemo
{
    public class ShallowSerializer
    {
        System.Type targetType;

        public ShallowSerializer(System.Type _targetType)
        {
            this.targetType = _targetType;


        }
        public System.Type TargetType
        {
            set { this.targetType = value; }
        }
        public object Deserialize(Stream serializationStream)
        {
            System.Xml.Serialization.XmlSerializer _formatter =
                    new System.Xml.Serialization.XmlSerializer(this.targetType);
            return _formatter.Deserialize(serializationStream);
        }

        public void Serialize(Stream serializationStream, object graph)
        {
            System.Xml.Serialization.XmlSerializer _formatter =
                new System.Xml.Serialization.XmlSerializer(this.targetType);
            _formatter.Serialize(serializationStream, graph);
        }
    }
    public class DeepSerializer
    {
        public void Serialize(object target,
            System.IO.Stream location,
            System.Runtime.Serialization.IFormatter formatter)
        {

            formatter.Serialize(location, target);
        }

        public object DeSerialize(System.IO.Stream location,
            System.Runtime.Serialization.IFormatter formatter)
        {
            object target = default(object);
            target = formatter.Deserialize(location);
            return target;
        }
    }


    [Serializable]
    public class ReferenceType //:ISerializable
    {
        private int member1 = 100;
        public string member2 = "Member2";

        public override string ToString()
        {
            return $"{member1} and {member2}";
        }

        public ReferenceType() { }
        //Deserialize
        public ReferenceType(SerializationInfo info, StreamingContext context)
        {
            this.member1 = info.GetInt32("Member1");
            this.member2 = info.GetString("Member2");
            var signature = info.GetInt32("Signature");
            if (this.GetHashCode() == signature)
            {
                Console.WriteLine("Object state free from tampering");

            }
            else
            {
                Console.WriteLine("Object state Modified");
            }
        }
        //Serialize
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Member1", this.member1);
            info.AddValue("Member2", this.member2);
            info.AddValue("Signature", this.GetHashCode());

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //   DeSerialize();
            Serialize();
        }

        static void Serialize()
        {
            ReferenceType _target = new ReferenceType();
            DeepSerializer _deepSerializer = new DeepSerializer();
            System.IO.StreamWriter _writer =
                new StreamWriter($"..//..//{_target.GetType().Name}.bin");
            _deepSerializer.Serialize(_target, _writer.BaseStream, new BinaryFormatter());
            _writer.Close();

            _writer = new StreamWriter($"..//..//{_target.GetType().Name}.soap");
            _deepSerializer.Serialize(_target, _writer.BaseStream, new SoapFormatter());
            _writer.Close();

            _writer = new StreamWriter($"..//..//{_target.GetType().Name}.xml");
            ShallowSerializer _shalowSerializer = new ShallowSerializer(typeof(ReferenceType));
            _shalowSerializer.Serialize(_writer.BaseStream, _target);
            _writer.Close();

        }

        static void DeSerialize()
        {
            DeepSerializer _deepSerializer = new DeepSerializer();

            System.IO.StreamReader _reader =
                         new StreamReader($"..//..//{typeof(ReferenceType).Name}.bin");

            object obj = _deepSerializer.DeSerialize(_reader.BaseStream, new BinaryFormatter());
            Console.WriteLine(obj.ToString());
            _reader.Close();

            _reader =
                         new StreamReader($"..//..//{typeof(ReferenceType).Name}.soap");
            _deepSerializer.DeSerialize(_reader.BaseStream, new SoapFormatter());
            Console.WriteLine(obj.ToString());
            _reader.Close();
        }
    }
}






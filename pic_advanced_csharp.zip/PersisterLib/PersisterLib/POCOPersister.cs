﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersisterLib
{
    [AttributeUsage(AttributeTargets.Property|AttributeTargets.Field,AllowMultiple =false)]
    public class IgnoreAttribute:System.Attribute
    {

    }

    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
    public class PersistedNameAttribute:System.Attribute
    {
        string name;
        public PersistedNameAttribute(string name)
        {
            this.name = name;
        }            
        public string Name { get { return name; } }

    }

    public enum PersistanceMode
    {
        ALL,PUBLIC,CUSTOM
    }
    public enum PersistanceFormat
    {
        JSON,XML,CSV,BINARY
    }

    [AttributeUsage(AttributeTargets.Class,AllowMultiple =false)]
    public class PersistableAttribute:System.Attribute
    {
        //Named Arguments
        public PersistanceMode PersistantMode { get; set; }
        public PersistanceFormat PersistantFormat { get; set; }

    }
    public class POCOPersister
    {
        public void Persist(object target)
        {
            //Reflection Code
           PersistableAttribute _persistableAttribute= CheckForPersistableType(target);


            
        }
        bool CheckForClassType(object target)
        {
            //Type Details
            return target.GetType().IsClass;
            
            
        }
        PersistableAttribute CheckForPersistableType(object target)
        {
            //Class Details
            if (CheckForClassType(target)){
                System.Type _classRef = target.GetType();
                //Check For Persistable Attribute
              PersistableAttribute[] attributes=
                    _classRef.GetCustomAttributes(typeof(PersistableAttribute), false)
                    as PersistableAttribute[];
                if (attributes.Length > 0)
                {
                    return attributes[0];
                }
                throw new Exception($"Type {target.GetType().FullName} Not Marked For Persistable");
            }
            throw new Exception($"Target Type Must be Class");
            


        }

    }
}

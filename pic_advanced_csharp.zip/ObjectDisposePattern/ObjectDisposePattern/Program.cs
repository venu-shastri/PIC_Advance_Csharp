﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectDisposePattern

{
    public static class Signals
    {
        public static System.Threading.AutoResetEvent _ReosurceStateSignal =
            new System.Threading.AutoResetEvent(false);
    }
    public enum ResourceState
    {
        BUSY,FREE
    }
    public class Resource
    {
        private Resource() {
           State = ResourceState.FREE;
        }
        public static readonly Resource Instance = new Resource();
        public ResourceState State { get; set; }
    }
    public class RW:IDisposable
    {
        bool isDisposed = false;

        public RW()
        {
            lock (Signals._ReosurceStateSignal)
            {
                if (Resource.Instance.State == ResourceState.FREE)
                {
                    Console.WriteLine($"Resource Owned By " +
                        $"{System.Threading.Thread.CurrentThread.ManagedThreadId}");
                    Resource.Instance.State = ResourceState.BUSY;
                }
                else
                {
                    Console.WriteLine($"{System.Threading.Thread.CurrentThread.ManagedThreadId} " +
                        $"Thread Awaiting For Resourced To Be Free");
                    Signals._ReosurceStateSignal.WaitOne();
                    Resource.Instance.State = ResourceState.BUSY;
                    Console.WriteLine($"Resource Owned By " +
                        $"{System.Threading.Thread.CurrentThread.ManagedThreadId}");
                }
            }
        }
        public void UseResource()
        {
            if (isDisposed) { throw new ObjectDisposedException("RW"); }
            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Resource Used  By " +
                    $"{System.Threading.Thread.CurrentThread.ManagedThreadId}");
                System.Threading.Thread.Sleep(1000);
            }
        }
         void Release()
        {
            Resource.Instance.State = ResourceState.FREE;
            Console.WriteLine($"Resource Released  By " +
                $"{System.Threading.Thread.CurrentThread.ManagedThreadId}");
            Signals._ReosurceStateSignal.Set();

        }

        public void Dispose()
        {
                Dispose(true);
        }
       
        ~RW()
        {

            Dispose(false);
        }

        protected void Dispose(bool isDisposing)
        {
            if (!isDisposed)
            {
                //true- Call From Dispose Method
                if(isDisposing)
                {
                    Console.WriteLine($"Object Destructed Using  Dispose Method ");
                    isDisposed = true;
                    GC.SuppressFinalize(this);

                }
                else
                {
                    //Finalize Method
                    Console.WriteLine($"Object Destructed Using  Finalize Method");
                }
                Release();
            }

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //new System.Threading.Thread(Client).Start();
            //new System.Threading.Thread(Client).Start();

            System.Threading.ThreadPool.QueueUserWorkItem(
                new System.Threading.WaitCallback((obj) => { Client(); }));

            System.Threading.ThreadPool.QueueUserWorkItem(
                new System.Threading.WaitCallback((obj) => { Client(); }));

            Console.ReadKey();
        }
        static void Client()
        {
            RW _rwRef = new RW();
            
           _rwRef.UseResource();
            
            _rwRef = null;
            
            GC.Collect();
            
           
        }
    }
}

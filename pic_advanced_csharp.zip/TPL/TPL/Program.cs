﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPL
{
    class Program
    {
        static void Main1(string[] args)
        {
            //Task 
            //Task<string>

            Task _task1 = new Task(() => {

                //Async Code 
                for(int i = 0; i < 10; i++)
                {
                    if (i == 5) { throw new Exception("Task 1 Exception"); }
                    Console.WriteLine($"Task1.....");
                    System.Threading.Thread.Sleep(1000);
                }

            });

            Task<string> _task2 = new Task<string>(() =>
              {
                  
                  for (int i = 0; i < 10; i++)
                  {
                      if (i == 8) { throw new Exception("Task 2 Exception"); }
                      Console.WriteLine($"Task2.....");
                      System.Threading.Thread.Sleep(1000);
                  }
                  return "Task 2  Completed";
              });

            _task1.Start();
            _task2.Start();
            try
            {
                Task.WaitAll(_task1, _task2);
            }
            catch(AggregateException ex)
            {
                foreach (var e in ex.Flatten().InnerExceptions)
                {
                    Console.WriteLine(e.Message);
                }

            }
            if (!_task2.IsFaulted)
            {
                Console.WriteLine(_task2.Result);
            }

        }

        static void Main2()
        {
            Task testRunner = new Task(() =>
            {
                Console.WriteLine("Test Runner Begin");

                Task testSuiteTask = new Task(() =>
                {
                    Console.WriteLine("Test Suite Task Begin");

                    Task testMethodTask = new Task(() =>
                    {
                        Console.WriteLine("Test Method Task Begin");
                        System.Threading.Thread.Sleep(15000);
                        Console.WriteLine("Test Method Task End");
                        throw new Exception("Test Method  Exception");
                    }, TaskCreationOptions.AttachedToParent);

                    testMethodTask.Start();
                    System.Threading.Thread.Sleep(5000);
                    Console.WriteLine("Test Suite TaskEnd");
                    throw new Exception("Test Suite Exception");
                },
                    TaskCreationOptions.AttachedToParent);

                testSuiteTask.Start();

                System.Threading.Thread.Sleep(1000);
                Console.WriteLine("Test Runner End");


            });

            testRunner.Start();
            try
            {
                testRunner.Wait();
            }
            catch(AggregateException ex)
            {
                foreach(var e in ex.Flatten().InnerExceptions)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        static void Main3()
        {
            while (true)
            {
                Console.WriteLine("Press Any Key To Send request");
                Console.ReadKey();
                SendNwRequest();
            }

        }

        static void SendNwRequest()
        {
            Task<int> requestTask = new Task<int>(() => {

                Console.WriteLine("Request Sent.....");
                System.Threading.Thread.Sleep(5000);
                Random _random = new Random();
                int value = _random.Next(0, 9);
                Console.WriteLine("Request End.....");
                return value;
            });

            Task<string> responseTask =
                requestTask.ContinueWith<string>((pt) =>
                {

                    Console.WriteLine("Response  Task.....");
                    System.Threading.Thread.Sleep(5000);
                    if (pt.Result % 2 == 0)
                    {
                        return $"Response Task Result {pt.Result}";
                    }
                    throw new Exception($"Response Exception {pt.Result}");

                }, TaskContinuationOptions.OnlyOnRanToCompletion);

            //logger Task
            responseTask.ContinueWith((pt) => {
                Console.WriteLine("Logger   Task..Logging...");
                System.Threading.Thread.Sleep(5000);
                Console.WriteLine($"Log Message...{pt.Exception.InnerException.Message}");
                Console.WriteLine("Logger   Task..Logging..Ended.");

            },TaskContinuationOptions.OnlyOnFaulted);

            //response Process Task
            responseTask.ContinueWith((pt) => {
                Console.WriteLine("Response Processing Task...");
                System.Threading.Thread.Sleep(5000);
                Console.WriteLine($"Processing  Result...{pt.Result}");
                Console.WriteLine("Response Porcess Task..Ended.");

            }, TaskContinuationOptions.OnlyOnRanToCompletion | TaskContinuationOptions.NotOnFaulted);

            requestTask.Start();
        }

        static void Main()
        {
            button_click();
            Console.ReadKey();
        }
        //Episodes
        //Return Type - void/Task
        //Can have await keyword
        static async void   button_click()
        {
            Console.WriteLine("Synchronous Code Block");//Episode1
            string result=await Task.Run<string>(() => {

                return Search("key");
               
            }); //Episode 2
        
            Console.WriteLine($"Updating Ui Thread {result}"); //Episode 3


            
            
        }

        static string Search(string key)
        {
            System.Threading.Thread.Sleep(10000);
            return key.ToUpper();
        }

    }
}

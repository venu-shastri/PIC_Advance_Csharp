﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParallelProgram
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Console.WriteLine(System.Environment.ProcessorCount);

            string[] dataSource= {"a","b","c","d","e","f","g","h" };
            List<string> encryptedDataSource = default(List<string>);
            System.Diagnostics.Stopwatch _watch = new System.Diagnostics.Stopwatch();
            _watch.Start();

                Partitioner.Create(dataSource,true).
                  AsParallel().WithDegreeOfParallelism(2).
                  Select(item => Encrypt(item)).
                  ForAll((item) => {

                      Console.WriteLine($"Chunk Data {item} " +
                          $"processed By {System.Threading.Thread.CurrentThread.ManagedThreadId} isThreadPoolThread {System.Threading.Thread.CurrentThread.IsThreadPoolThread}");
                  });

            DisplayOnConsole(dataSource.ToList());
            //DisplayOnConsole(encryptedDataSource);
            _watch.Stop();
            Console.WriteLine($"Total Time {_watch.ElapsedMilliseconds}");
        }

       static string Encrypt(string item)
        {
            if (item == "j")
            {
                System.Threading.Thread.Sleep(10000);
            }
            System.Threading.Thread.Sleep(100);
            return item.ToUpper();
        }
        static void DisplayOnConsole(List<string> source)
        {
            Console.WriteLine("******************************");
            Parallel.ForEach(source, (item) =>{

                    System.Threading.Thread.Sleep(100);
                Console.WriteLine($"Chunk Data {item} " +
           $"processed By {System.Threading.Thread.CurrentThread.ManagedThreadId}" +
           $" isThreadPoolThread {System.Threading.Thread.CurrentThread.IsThreadPoolThread}");
            });
        }
    }
}
